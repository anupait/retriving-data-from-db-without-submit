<?php
$q=$_GET["q"];

$con = mysql_connect('localhost', 'root', '');
mysql_select_db("test", $con);

$sql="SELECT * FROM stuinfo WHERE stu_id ='$q'";

$result = mysql_query($sql);

echo "<table border='1'>
<tr>
<th>Email </th>
<th>Mobile</th>
</tr>";

while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['name'] . "</td>";
  echo "<td>" . $row['mobile'] . "</td>";
  echo "</tr>";
  }
echo "</table>";

mysql_close($con);
?> 
