<html>
<head>
<script>

function showUser(str)
{
if (str=="")
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  } 
  
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  
  
  
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","getdatafromDB.php?q="+str,true);
xmlhttp.send();
}
</script>
</head>


<body>
<select name="users" onChange="showUser(this.value)">
<option value="" selected="selected" disabled="disabled">Select a person:</option>

<option value="1">vikash</option>
<option value="2">ravi</option>
<option value="3">sandeep</option>
<option value="4">saurabh</option>
</select>

<br/>
<div id="txtHint" style="width:400px; border:2px solid red;"><b>Person info will be listed here.</b></div>

</body>
</html> 
